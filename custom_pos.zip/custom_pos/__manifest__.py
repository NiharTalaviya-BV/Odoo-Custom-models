{
    'name': 'Custom_Pos',
    'version': '16.0',
    'summary': 'Module for customize the POS',
    'description': 'Custom Pos Module',
    'sequence': '1',
    'author': 'Nihar Talaviya',
    'category': 'Sale',
    'depends': ['point_of_sale', 'base'], 
    'data': [
        'security/ir.model.access.csv',
        'views/custom_pos.xml',
        'views/inherit_pos_order_view.xml',
       
    ],

    'assets': {
      'point_of_sale.assets': [
                               'custom_pos/static/src/js/PhoneNumberButton.js',
                               'custom_pos/static/src/js/PhoneNumberButton.xml',
                               'custom_pos/static/src/js/PhoneNumberPopup.js',
                               'custom_pos/static/src/js/PhoneNumberPopup.xml',
                               'custom_pos/static/src/js/ExtendedOrder.js',
                            ]
    },


    'installable': True,
    'application': True,
    'auto_install': True,
    'license': 'LGPL-3'
}
